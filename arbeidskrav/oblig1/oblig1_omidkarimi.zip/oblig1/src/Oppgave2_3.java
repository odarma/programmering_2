public class Oppgave2_3{
    public static void main(String[] args) {
        Planet planet1 = new Planet("mars", 3889.5, 6.39E23);
        System.out.println(planet1);
        Planet planet2 = new Planet("jorda", 40000, 10.39E24);
        System.out.println(planet2);
        Planet planet3 = new Planet("jupiter", 60000, 10E29);
        System.out.println(planet3);
    }
}
